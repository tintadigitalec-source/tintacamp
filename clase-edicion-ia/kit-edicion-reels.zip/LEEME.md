# Kit de edición de reels con Claude

Tres skills para editar tus reels en Claude:

- **editor-reels**: toma crudo → reel vertical con cortes, subtítulos karaoke y título gancho.
- **look-reels**: crea tu guía de marca (`marca.md`) con vista previa.
- **efectos-reels**: 19 efectos, cada uno con su código (zoom, lento, glitch, cuenta, pantalla-dividida…). Ver el catálogo completo dentro del SKILL.md o en la presentación.

## Instalar (una vez)
1. En Claude, ve a Configuración › Capacidades y activa «Crear y editar archivos».
2. Ve a Personalizar › Skills, toca **+** › Crear skill › Subir una skill.
3. Sube cada ZIP por separado: `editor-reels.zip`, `look-reels.zip`, `efectos-reels.zip`. No los descomprimas.
   **Ojo:** `kit-edicion-reels.zip` (la caja que trae todo) NO se sube: Claude lo rechaza porque no es una skill.
4. Revisa que las tres estén activadas.

## Usar
1. Abre un chat nuevo, adjunta tu video y escribe: `/editor-reels edita este video, título: "tu gancho"`.
2. ¿Quieres tu propio estilo? `/look-reels créame mi marca` y guarda el `marca.md` que te entrega. En adelante, adjúntalo junto a tu video.
3. ¿Voz en off? Adjunta tu audio, 4 a 6 fotos y tu guion: `/editor-reels arma un reel con esta voz en off y estas fotos`.
4. Agrega efectos: `/efectos-reels zoom cuando digo "gratis" y barra de progreso`.

Si Claude no puede transcribir tu audio automáticamente, te pedirá el texto de lo que dijiste: pégalo y listo.

Fuentes incluidas (Anton, Inter, DM Serif Display) bajo licencia SIL Open Font License.
